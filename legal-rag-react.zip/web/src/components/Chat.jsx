
import React, { useState, useEffect, useRef } from 'react'
import { ask, rebuild, health } from '../api'
export default function Chat() {
  const [ready, setReady] = useState(false)
  const [loading, setLoading] = useState(false)
  const [rebuilding, setRebuilding] = useState(false)
  const [question, setQuestion] = useState('What is a valid consideration under the Indian Contract Act?')
  const [messages, setMessages] = useState([])
  const endRef = useRef(null)
  useEffect(() => { health().then(() => setReady(true)).catch(() => setReady(false)) }, [])
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  const onAsk = async () => {
    if (!question.trim()) return
    setLoading(true)
    try {
      const res = await ask(question, 5)
      setMessages(m => [...m, { role: 'user', text: question }, { role: 'assistant', text: res.answer, citations: res.citations }])
      setQuestion('')
    } catch (e) {
      setMessages(m => [...m, { role: 'system', text: e.message }])
    } finally { setLoading(false) }
  }
  const onRebuild = async () => {
    if (!confirm('Rebuild index from PDFs in server/data/?')) return
    setRebuilding(true)
    try { await rebuild(); setMessages(m => [...m, { role: 'system', text: 'Index rebuilt successfully.' }]) }
    catch (e) { setMessages(m => [...m, { role: 'system', text: e.message }]) }
    finally { setRebuilding(false) }
  }
  return (
    <div style={{border:'1px solid #e5e7eb', borderRadius:12, padding:16}}>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={question} onChange={e => setQuestion(e.target.value)}
          placeholder="Ask a question about Indian Contract Law..." style={{flex:1, padding:'10px 12px', borderRadius:8, border:'1px solid #d1d5db'}}
          onKeyDown={e => e.key === 'Enter' && onAsk()} />
        <button onClick={onAsk} disabled={!ready || loading} style={{padding:'10px 14px', borderRadius:8}}>
          {loading ? 'Thinking...' : 'Ask'}
        </button>
        <button onClick={onRebuild} disabled={rebuilding} style={{padding:'10px 14px', borderRadius:8}}>
          {rebuilding ? 'Rebuilding...' : 'Rebuild Index'}
        </button>
      </div>
      <div style={{height: '55vh', overflowY:'auto', padding:8, background:'#fafafa', borderRadius:8}}>
        {messages.map((m, i) => (
          <div key={i} style={{margin: '8px 0'}}>
            <div style={{fontSize:12, color:'#888'}}>{m.role.toUpperCase()}</div>
            <div style={{whiteSpace:'pre-wrap'}}>{m.text}</div>
            {m.citations && m.citations.length > 0 && (
              <div style={{marginTop:6, fontSize:12, color:'#444'}}>
                <b>Citations:</b>
                <ul>
                  {m.citations.map((c, j) => (
                    <li key={j}>
                      {c.source}{c.page !== null && c.page !== undefined ? `:p${c.page}` : ''}
                      {c.snippet ? ` — “${c.snippet.slice(0,120)}...”` : ''}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {!ready && <div style={{marginTop:8, color:'#b91c1c'}}>Backend not reachable. Start FastAPI on port 8000.</div>}
    </div>
  )
}
