
import React from 'react'
import Chat from './components/Chat'
export default function App() {
  return (
    <div style={{maxWidth: 900, margin: '2rem auto', fontFamily: 'Inter, system-ui, sans-serif'}}>
      <h1>🧑‍⚖️ Legal Assistant (RAG) — Indian Contract Law</h1>
      <p style={{color:'#666'}}>Ask grounded questions from your indexed PDFs. Not legal advice.</p>
      <Chat />
      <footer style={{marginTop:'2rem', fontSize:12, color:'#888'}}>React + FastAPI + FAISS + LangChain</footer>
    </div>
  )
}
