
import os, pickle
from typing import List, Tuple, Dict, Any
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document
from sentence_transformers import SentenceTransformer

STORAGE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'storage'))
INDEX_PATH = os.path.join(STORAGE_DIR, 'index.faiss')
STORE_PATH = os.path.join(STORAGE_DIR, 'index.pkl')

def _ensure_dirs():
    os.makedirs(STORAGE_DIR, exist_ok=True)

def embedding_fns():
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        model = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
        emb = OpenAIEmbeddings(model=model)
        return emb.embed_query, emb.embed_documents, 1536, f"openai:{model}"
    st_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    dim = st_model.get_sentence_embedding_dimension()
    def _q(x: str): return st_model.encode(x).tolist()
    def _d(texts: List[str]): return st_model.encode(texts).tolist()
    return _q, _d, dim, "sbert:all-MiniLM-L6-v2"

def load_vectorstore() -> Tuple[FAISS, Dict[str, Any]]:
    _ensure_dirs()
    if not (os.path.exists(INDEX_PATH) and os.path.exists(STORE_PATH)):
        raise FileNotFoundError("Vector index not found. Run the ingest step first.")
    with open(STORE_PATH, 'rb') as f:
        store = pickle.load(f)
    vs = FAISS.load_local(STORAGE_DIR, embeddings=None, allow_dangerous_deserialization=True)
    return vs, store.get("meta", {})

SYS_PROMPT = (
    "You are a legal assistant specialized in Indian Contract Law.\n"
    "Answer strictly from the retrieved context snippets. If the answer is not in the context, say you don't have enough information.\n"
    "Keep answers concise, neutral, and cite sources with (filename:page). Quote key lines when helpful.\n"
    "Avoid giving legal advice; provide information only.\n"
)

def format_context(docs: List[Document]) -> str:
    blocks = []
    for d in docs:
        meta = d.metadata or {}
        fn = meta.get('source', 'unknown')
        page = meta.get('page', None)
        header = f"[{fn}:{page}]" if page is not None else f"[{fn}]"
        blocks.append(f"{header}\n{d.page_content.strip()}"[:2000])
    return "\n\n".join(blocks)

def generate_answer(question: str, docs: List[Document]) -> Tuple[str, List[Dict[str, Any]]]:
    openai_key = os.getenv("OPENAI_API_KEY")
    citations = [{
        "source": (d.metadata or {}).get('source', 'unknown'),
        "page": (d.metadata or {}).get('page'),
        "snippet": d.page_content[:260]
    } for d in docs]

    if openai_key:
        from langchain.prompts import ChatPromptTemplate
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        llm = ChatOpenAI(model=model, temperature=0.1)
        prompt = ChatPromptTemplate.from_messages([
            ("system", SYS_PROMPT),
            ("human", "Question: {question}\n\nContext:\n{context}\n\nAnswer:")
        ])
        chain = prompt | llm
        out = chain.invoke({"question": question, "context": format_context(docs)})
        return out.content.strip(), citations

    joined = "\n---\n".join([d.page_content for d in docs])
    answer = ("No generative model configured. Based on retrieved context, here are relevant excerpts:\n\n"
              + joined[:1200])
    return answer, citations
