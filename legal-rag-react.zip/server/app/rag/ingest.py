
import os, glob, pickle
from typing import List
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document
from langchain.vectorstores import FAISS
from .chain import STORAGE_DIR, STORE_PATH, embedding_fns

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))

def load_pdfs() -> List[Document]:
    pdfs = sorted(glob.glob(os.path.join(DATA_DIR, "*.pdf")))
    if not pdfs:
        raise FileNotFoundError(f"No PDFs found in {DATA_DIR}. Add files and retry.")
    docs = []
    for p in pdfs:
        loader = PyPDFLoader(p)
        per_page = loader.load()
        for d in per_page:
            d.metadata = d.metadata or {}
            d.metadata['source'] = os.path.basename(p)
        docs.extend(per_page)
    return docs

def chunk_docs(docs: List[Document]):
    size = int(os.getenv("CHUNK_SIZE", "900"))
    overlap = int(os.getenv("CHUNK_OVERLAP", "150"))
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=size,
        chunk_overlap=overlap,
        separators=["\n\n", "\n", " ", ""],
    )
    return splitter.split_documents(docs)

def build_faiss(chunks: List[Document]):
    embed_q, embed_d, dim, provider = embedding_fns()
    from langchain.embeddings.base import Embeddings
    class ShimEmb(Embeddings):
        def embed_query(self, text: str): return embed_q(text)
        def embed_documents(self, texts: List[str]): return embed_d(texts)

    vec = FAISS.from_documents(chunks, ShimEmb())
    os.makedirs(STORAGE_DIR, exist_ok=True)
    vec.save_local(STORAGE_DIR)
    with open(STORE_PATH, 'wb') as f:
        pickle.dump({"meta": {"provider": provider, "dim": dim}}, f)

def main():
    print("Loading PDFs...")
    docs = load_pdfs()
    print(f"Loaded {len(docs)} pages.")
    print("Chunking...")
    chunks = chunk_docs(docs)
    print(f"Chunks: {len(chunks)}")
    print("Embedding + building FAISS...")
    build_faiss(chunks)
    print("OK. Index written to:", STORAGE_DIR)

if __name__ == "__main__":
    main()
