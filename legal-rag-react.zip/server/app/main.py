
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.schemas.models import AskRequest, AskResponse, RebuildResponse
from app.rag.chain import load_vectorstore, generate_answer
from app.rag.ingest import main as rebuild_index

app = FastAPI(title="Legal RAG API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/ingest/rebuild", response_model=RebuildResponse)
def ingest_rebuild():
    try:
        rebuild_index()
        return {"status": "rebuilt"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    try:
        vs, _ = load_vectorstore()
    except FileNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    docs = vs.similarity_search(req.question, k=req.k)
    if not docs:
        return {"answer": "I couldn't find relevant context in the indexed documents.", "citations": []}
    answer, citations = generate_answer(req.question, docs)
    return {"answer": answer, "citations": citations}
