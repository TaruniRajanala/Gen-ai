
from pydantic import BaseModel, Field
from typing import List, Optional

class AskRequest(BaseModel):
    question: str = Field(..., min_length=3)
    k: int = Field(5, ge=1, le=10)

class Citation(BaseModel):
    source: str
    page: Optional[int] = None
    snippet: Optional[str] = None

class AskResponse(BaseModel):
    answer: str
    citations: List[Citation]

class RebuildResponse(BaseModel):
    status: str
