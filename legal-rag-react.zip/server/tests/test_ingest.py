
import os
from app.rag.ingest import DATA_DIR

def test_data_dir_exists():
  assert os.path.isdir(DATA_DIR)
